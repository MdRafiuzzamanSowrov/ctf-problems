from hashlib import sha256

def m(p): return sha256(p.encode()).digest()

def r():
    p="guess"
    k=m(p)
    print(k.hex())

if __name__=="__main__":
    r()

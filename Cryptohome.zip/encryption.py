from hashlib import sha256

def m(y,w):
    """ Given year and word strings, produce AES-256 key: key = SHA256(f"{year}:{word}") 
    you must find the correct year and word from challenge hints. """
    return sha256((y+":"+w).encode()).digest()

def run():
    y="YYYY"
    w="word"
    k=m(y,w)
    print(k.hex())

if __name__=="__main__":
    run()

@echo off
setlocal enabledelayedexpansion
set flag_enc=102 108 97 103 123 105 97 109 98 97 116 99 104 125
set "flag_dec="
for %%i in (%flag_enc%) do (
    set /a "char=%%i"
    for /f %%j in ('cmd /c "echo !char! && cmd /c exit"') do (
        for %%k in ("%%~j") do set "flag_dec=!flag_dec!%%~k"
    )
)
echo !flag_dec!
pause

import base64

def custom_encrypt(data, k):
    mask = [ord(c) for c in k]
    enc = []
    for i, d in enumerate(data.encode()):
        temp = d ^ mask[i % len(mask)]
        temp = (temp + 11) % 256
        enc.append(temp)
    return base64.b64encode(bytes(enc)).decode()

flag = "CS{Flagwillbehere}"
key = "***k3dC0mpLex"  # <- Oops, we forgot part of the key!
ciphertext = custom_encrypt(flag, key)
print(ciphertext)

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import base64
raw_key = ""
key = base64.b64encode(raw_key.encode()).ljust(16)[:16]
iv = b''
def encrypt_and_obfuscate(message):
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted_message = cipher.encrypt(pad(message.encode(), AES.block_size))
    base64_encoded = base64.b64encode(encrypted_message).decode()
    hex_encoded = base64_encoded.encode().hex() 
    return hex_encoded
flag = ""
cipher_obfuscated = encrypt_and_obfuscate(flag)
print("Obfuscated Ciphertext:", cipher_obfuscated)
print("IV (Base64):", base64.b64encode(iv).decode())

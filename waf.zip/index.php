<?php

require_once("db.php");

function firewall($input)
{
    if(preg_match("/([^a-z])+/s",$input))
    {
        return true;
    }
    else
    {
        return false;
    }
}


if(isset($_POST['submit']))
{
	if(!empty($_POST['username'])&&!empty($_POST['password']))
	{
        $username=$_POST['username'];
		$password=md5($_POST['password']);
        if(firewall($username))
        {
            die("You Have Been Blocked By WAF");
        }
        else
        {
            $res = $conn->query("select * from users where username='$username' and password='$password'");
            if($res->num_rows ===1)
            {
                echo "flag{test_flag}";
            }
            else
            {
                echo "<script>alert('Upss!! Wrong Credentials')</script>";
            }
    }

	}
	else
	{
		echo "<script>alert('Please Fill All Fields')</script>";
	}
}




?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <h2>Welcome Back</h2>
                <p>Please login to your account</p>
            </div>
    
    
            <form method="POST"  class="login-form">
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="userName" name="username" placeholder="Enter your username" required autofocus>
                </div>
    
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="pwd" name="password" placeholder="Enter your password" required>
                </div>
    
                <button type="submit" name="submit" class="login-button">Sign In</button>
            </form>
        </div>
    </div>
    
    <style>
        :root {
            --primary-color: #4361ee;
            --primary-hover: #3a56d4;
            --text-color: #2b2d42;
            --light-gray: #f8f9fa;
            --border-color: #e9ecef;
            --error-color: #ef233c;
            --white: #ffffff;
        }
    
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: var(--light-gray);
            padding: 20px;
        }
    
        .login-card {
            background: var(--white);
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            padding: 40px;
            width: 100%;
            max-width: 450px;
        }
    
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
    
        .login-header h2 {
            color: var(--text-color);
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 8px;
        }
    
        .login-header p {
            color: #6c757d;
            font-size: 16px;
        }
    
        .form-group {
            margin-bottom: 20px;
        }
    
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-color);
            font-weight: 500;
        }
    
        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
    
        .form-group input:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
        }
    
        .login-button {
            width: 100%;
            padding: 14px;
            background-color: var(--primary-color);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-top: 10px;
        }
    
        .login-button:hover {
            background-color: var(--primary-hover);
        }
    
        .alert-message {
            background-color: #fff3f3;
            color: var(--error-color);
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid var(--error-color);
            font-size: 14px;
        }
    
        .login-footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #6c757d;
        }
    
        .login-footer a {
            color: var(--primary-color);
            text-decoration: none;
            transition: color 0.3s;
        }
    
        .login-footer a:hover {
            text-decoration: underline;
        }
    
        .login-footer p {
            margin-bottom: 10px;
        }
    </style>
</body>
</html>